#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

void syscall_init (void);
int get_exit_code(void);
#endif /* userprog/syscall.h */
